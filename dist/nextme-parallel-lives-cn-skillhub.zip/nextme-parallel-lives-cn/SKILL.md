---
name: nextme-parallel-lives-cn
display_name: NextMe三条平行人生探索教练
display_name_en: NextMe Parallel Lives Coach
description: NextMe三条平行人生探索教练：用于第二曲线课后探索，深化未来画面、整理母题并形成愿意先了解的方向；完整报告后停止，不进行商业模式分析。
description_zh: 深化三条平行人生，找到核心母题，一起形成愿意先了解的方向，完整报告后结束。
description_en: Explore three parallel lives, reflect on recurring themes, and shape
  a provisional direction. Stop after the integrated report.
category: life-service
version: 4.1.1
author: NextMe
license: MIT
---

# NextMe三条平行人生探索教练

## 这个 Skill 做什么

NextMe第二曲线实验室的课后 AI 教练。通过温和追问，陪你展开三种未来生活，发现反复出现的吸引点，再一起形成一个目前愿意先了解的方向。它不替你推荐职业，也不急着判断能不能赚钱。

## 适用什么场景

- 已在课堂上想象过三条平行人生，想在课后继续聊深一些。
- 正在探索第二职业曲线，有几个模糊想法，但还没想清楚想靠近什么。
- 没参加课堂、没有准备材料，希望从头开始推演。

课堂画面、同伴反馈、Knowing Why / How / Whom 的材料都可选。可以上传，也可以口述，想到什么就说什么，不用刻意准备。

## 会帮助你产出什么

**第一轮报告**：三条平行人生深化版、核心母题及解释，以及各条路径的重要差异和还没想清楚的地方。

**第二轮报告**：在继续讨论你的新发现后，把两轮内容合并，增加你认可的方向草稿、它的来由、与其他路径的关系，以及留给下一步商业模式推演和用户访谈的未知问题。方向可以保留原路径，也可以重新组合，不要求三选一。

一次只问一个问题，完整报告后结束，不自动进入下一阶段。暂时没有形成方向时，会如实整理已有发现和缺口。

## 运行规则

调用本 Skill 时，先完整读取 [教练对话流程](references/coaching-flow.md)，再按其中规则从用户当前进度开始。不要仅凭这份简介开展教练对话。完整报告后结束，不再追问。
